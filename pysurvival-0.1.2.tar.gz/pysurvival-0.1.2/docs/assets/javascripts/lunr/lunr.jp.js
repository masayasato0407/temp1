module.exports=require("./lunr.ja");
